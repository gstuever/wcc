/**
 * @file
 * JavaScript behaviors for Webform Bootstrap test module.
 */

(function ($, Drupal) {

  'use strict';

})(jQuery, Drupal);
