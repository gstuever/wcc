CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Requirements
 * Installation
 * Configuration
 * Maintainers


INTRODUCTION
------------
The modules provides a configurable block that display links (icons) to your
profiles on various popular networking sites.
With this module, a website can be quickly extended with a "Follow us"
functionality. Or you make the block available for your site editors, and they
can configure the social networks themselves.


REQUIREMENTS
------------
This module does not have any dependency on any other module.


INSTALLATION
------------
Install as normal (see http://drupal.org/documentation/install/modules-themes).


CONFIGURATION
------------
The module has no special configuration. All settings are available in the
block settings: /admin/structure/block


MAINTAINERS
-----------
 * Neslee Canil Pinto: https://www.drupal.org/u/neslee-canil-pinto
 * Christian Beier: https://www.drupal.org/u/cbeier
