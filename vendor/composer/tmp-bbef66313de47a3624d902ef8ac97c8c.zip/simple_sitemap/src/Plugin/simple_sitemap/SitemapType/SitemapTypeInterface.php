<?php

namespace Drupal\simple_sitemap\Plugin\simple_sitemap\SitemapType;

/**
 * Interface SitemapTypeInterface
 * @package Drupal\simple_sitemap\Plugin\simple_sitemap\SitemapType
 */
interface SitemapTypeInterface {
}
