<?php

namespace Drupal\simple_sitemap\Plugin\simple_sitemap\SitemapType;

use Drupal\simple_sitemap\Plugin\simple_sitemap\SimplesitemapPluginBase;

/**
 * Class SitemapTypeBase
 * @package Drupal\simple_sitemap\Plugin\simple_sitemap\SitemapType
 */
abstract class SitemapTypeBase extends SimplesitemapPluginBase implements SitemapTypeInterface {
}
